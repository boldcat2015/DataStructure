/**
 * Requirement:
 * Evaluate the value of an arithmetic expression in Reverse Polish Notation.
 * For more definition about RPN, please refer to 
 * http://en.wikipedia.org/wiki/Reverse_Polish_notation .
 * 
 * Valid operators are +, -, *, /. Each operand may be an integer or another expression.
 * Some examples:
 *   ["2", "1", "+", "3", "*"] -> ((2 + 1) * 3) -> 9
 *   ["4", "13", "5", "/", "+"] -> (4 + (13 / 5)) -> 6
 * 
 Note that there may be invalid inputs. On invalid inputs, your program should return 0.
 * 
 * ++++++++++++++ 
 * The algorithm for evaluating an standard arithmetic expression 
 * in Reverse Polish Notation is fairly straightforward:
 * 
 *  While there are input tokens left:
 *      read the next token from input.
 *      if (the token is a number)
 *          Push it onto the stack.
 *      else{
            Pop the top 2 number from the stack
 *          Evaluate the operator, with the values as arguments
 *          Push the returned results, if any, back onto the stack
 *      }
 *  Return the last value in the stack
 * ++++++++++++++   
 * 
 * Some examples:
 *   ["2", "1", "+", "3", "*"] -> ((2 + 1) * 3) -> 9
 *   ["4", "13", "5", "/", "+"] -> (4 + (13 / 5)) -> 6
 *   ["4", "13", "5",  "+"] -> 0 (extra number)
 *   ["+", "13", "5",  "+"] -> 0 (invalid operator)
**/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int evalRPN(char** tokens, int tokensSize){
/* Your implementation of evalRPN should start here. */



/* End of your implementation. */
}



