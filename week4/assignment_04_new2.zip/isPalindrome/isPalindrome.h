/**
 * Requirements:
 * Given a singly linked list, determine if it is a palindrome.
 * 
 * We define a list to be palindrome if and only if the linked 
 * list has node vals in the same order wether you read from the head or the tail.
 * e.g. 1->2->3->2->1
 * 
 * BONUS for solutions using O(1) space!!!
**/

struct ListNode {
    int val;
    struct ListNode *next;
};

bool isPalindrome(struct ListNode* head) {
/* Your code should start here. */

/* End of your code. */
}