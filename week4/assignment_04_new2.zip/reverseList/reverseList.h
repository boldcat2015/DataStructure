/**
 * Requirement:
 * Reverse a singly linked list
 * and return the head of the reversed list. 
**/

struct ListNode {
    int val;
    struct ListNode *next;
};

void reverseList(struct ListNode* head) {
/* Your code should start from here. */
/* Note that from this time on, struct ListNode* head is default to be a meaningless struct
   which is the predecessing node of the list of nodes of some meaning. */

   
   
/* End of your code. */
}