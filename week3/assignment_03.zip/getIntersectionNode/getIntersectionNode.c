/**
 * Write a program to find the node at which 
 * the intersection of two singly linked lists begins.
 * 
 * 
 * For example, the following two linked lists:
 * 
 * A:          a1 → a2
 *                    ↘
 *                      c1 → c2 → c3
 *                   ↗            
 * B:     b1 → b2 → b3
 * begin to intersect at node c1.
 * 
 * 
 * Notes:
 * 1. If the two linked lists have no intersection at all, return null.
 * 2. The linked lists must retain their original structure after the function returns.
 * 3. You may assume there are no cycles anywhere in the entire linked structure.
 * 4. Your code should preferably run in O(n) time and use only O(1) memory.
**/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define NUMCASE 10000

/* Definition for singly-linked list.*/
struct ListNode {
    int val;
    struct ListNode *next;
};
 
struct ListNode *getIntersectionNode(struct ListNode *headA, struct ListNode *headB) {
/* Your code should start from here. */
    
    
    
    
    
    
/* End of your code. */
}
