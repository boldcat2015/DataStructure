/**
 * Given a string containing '(', ')', '{', '}', '[' and ']'
 * determine if the input string is valid. 
 * You may not change the input string. 
 * 
 * The brackets must close in the correct order. 
 * "()" and "()[]{}" are all valid but "(]" and "([)]" are not.
 * 
 * Hint:
 * If the lastest unbalanced left bracket encountered is '(', 
 * then the next right bracket must be ')' in order to balance it.
 * To validate the input sentence, every left bracket should be 
 * balalenced with a right bracket, and every right bracket should
 * be able to balance the lastest unbalanced left bracket. 
 * 
 * One way to do it is to push every left bracket into the stack,
 * and pop the top element when encountering the correct right bracket. 
**/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include<stdbool.h>

bool isValid(char* s) {
/* Your code should start from here. */





/* End of your code. */
}
