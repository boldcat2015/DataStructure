/**
 * You are required to implement three functions:
 * 1. <creatMat>
 *    Creat a TSMatrix from a matrix input. 
 * 2. <findValue>
 *    Given a coordinate, find the corresponding value. 
 *    If there is an entry for the indices, return the value. Otherwise, return 0. 
 * 3. <multiMat>
 *    Impliment matrix multiplication operation on TSMatrix. 
 *    You are required to not only do the multiplication on legal inputs, 
 *    but also detect illegal inputs. 
 *    On legal input, your function should return the resulted TSMatrix. 
 *    On illegal input, your function should return NULL pointer. 
 * In your report, please focus your analysis on the latter two functions. 
 * 
 * Note:
 * 1. There may be some difference between the return types of functions in the assignments
 *    and that in the slides. Please strict to the assignment reqiremnts. 
 * 2. In <creatMat> and <multiMat>, the returned TSMatrix should be malloced, 
 *    You may expect <free> function in the testbench. 
 * 
 * Hints:
 * 1. You may call your <findValue> function when implimenting multiplication. 
 * 
 * 2. The definition of matrix multiplication is given by
 *        C(X*Z) = A(X*Y) * B(Y*Z)
 *        where C[i][j] = sum(A[i][k] * B[k][j]), k = 0,1,2,...,Y-1
 *    If we strictly follow the definition, we may end up code like
 *        for (i = 0; i < X; i++)
 *            for (j = 0; j < Z; j++)
 *                C[i][j] = 0;
 *                for (k = 0; k < Y; k++)
 *                    C[i][j] += A[i][k] * B[k][j];
 * 
**/
#include<stdio.h>
#include<stdlib.h>
#define MaxSize 100
typedef int ElemType;
typedef struct{
    int row;
    int col;
    ElemType val;
} TupNode;
typedef struct{
    int rowSize;
    int colSize;
    int nums;
    TupNode data[MaxSize];
} TSMatrix;
/* Definition of Sparse Matrix. */

TSMatrix* createMat(ElemType** mat, int rowSize, int colSize){
/* Create a TSMatrix from a 2D array. */

/* End of your <createMat> */
}

ElemType findValue(TSMatrix *t, int i, int j){
/* Find a value based on (i,j) coordinate. Return 0 if no value is found. */

/* End of <findValue> */
}

TSMatrix* multiMat(TSMatrix *matA, TSMatrix *matB){
/* Your implimentation of matric multiplication here. */

/* End of your code. */
}
